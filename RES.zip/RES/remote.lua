local kb = libs.keyboard;


-- Documentation
-- http://www.unifiedremote.com/api

-- Keyboard Library
-- http://www.unifiedremote.com/api/libs/keyboard


--@help Command 1
actions.command1 = function ()
	kb.stroke("k");
end


--@help Command 2
actions.command2 = function ()
	kb.stroke("j");
end


--@help Command 3
actions.command3 = function ()
	kb.stroke("x");
end

--@help Command 4
actions.command4 = function ()
	kb.stroke("shift" , "k");
end
--@help Command 5
actions.command5 = function ()
	kb.stroke("shift" , "j");

end
--@help Command 6
actions.command6 = function ()
	kb.stroke("a");

end
--@help Command 7
actions.command7 = function ()
	kb.stroke("z");

end
--@help Command 8
actions.command8 = function ()
	kb.stroke("shift" , "c");

end
--@help Command 9
actions.command9 = function ()
	kb.stroke("cmd" , "w");

end
--@help Command 10
actions.command10 = function()
os.execute('open "http://reddit.com"' );
end